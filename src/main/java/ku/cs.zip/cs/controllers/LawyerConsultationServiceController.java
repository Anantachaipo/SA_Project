package ku.cs.controllers;

public class LawyerConsultationServiceController {
}
