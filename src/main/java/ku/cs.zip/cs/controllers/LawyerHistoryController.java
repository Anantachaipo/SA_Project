package ku.cs.controllers;

public class LawyerHistoryController {
}
