package ku.cs.controllers;

public class LawyerWarnController {
}
