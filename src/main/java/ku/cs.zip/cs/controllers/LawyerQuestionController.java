package ku.cs.controllers;

public class LawyerQuestionController {
}
